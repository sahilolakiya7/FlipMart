import React, { createContext, useContext, useState, useEffect } from 'react';
import { lightTheme, darkTheme } from '../components/Theme/theme';
import { useColorScheme } from 'react-native';

const ThemeContext = createContext();

const ThemeProvider = ({ children }) => {
    const systemColorScheme = useColorScheme(); // Get system theme
    const [themeMode, setThemeMode] = useState(systemColorScheme || 'light'); // Default to system setting

    // Update theme when system preference changes
    useEffect(() => {
        setThemeMode(systemColorScheme || 'light');
    }, [systemColorScheme]);

    const theme = themeMode === 'dark' ? darkTheme : lightTheme;

    const toggleTheme = () => {
        setThemeMode(prevMode => (prevMode === 'light' ? 'dark' : 'light'));
    };

    return (
        <ThemeContext.Provider value={{ theme, toggleTheme,themeMode }}>
            {children}
        </ThemeContext.Provider>
    );
};

// Custom hook for consuming theme context
export const useTheme = () => useContext(ThemeContext);

export default ThemeProvider;
