import React from 'react'
import { createDrawerNavigator } from '@react-navigation/drawer';
import DrawerContent from './DrawerContent';
import Ionicons from 'react-native-vector-icons/Ionicons'
import { useTheme } from '../../context/ThemeProvide';
import BottomTabNavigator from '../Bottom/BottomTabNavigator';
const Drawer = createDrawerNavigator();

const DrawerNavigation = () => {
  const {theme} = useTheme();
  return (
    <Drawer.Navigator
    drawerContent={props => <DrawerContent {...props} />}
    screenOptions={{
      headerShown:false,
      drawerActiveBackgroundColor:theme.backgraundColor,
      drawerActiveTintColor:theme.themeColor,
      drawerInactiveTintColor:theme.COLORS.grey1,
      drawerLabelStyle:{marginLeft:-25},
    }}>
      <Drawer.Screen name="BottomTab" component={BottomTabNavigator} 
        options={{
          drawerLabel:"Home",
          drawerIcon:({color,focused})=>(
            <Ionicons name={focused ? "home" : "home-outline"} size={20} color={color} />
          ),
        }}
      />
        
    </Drawer.Navigator>
  )
}

export default DrawerNavigation