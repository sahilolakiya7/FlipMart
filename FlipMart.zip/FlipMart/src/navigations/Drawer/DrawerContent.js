import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import React from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { Avatar } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../../context/ThemeProvide';
import images from '../../../assets/animation/images';

const DrawerContent = (props) => {
  const { theme } = useTheme();
  const navigation = useNavigation();

  const handleLogout = () => {
    console.log('User logged out');
    navigation.navigate('Signin');
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}> 
      <View style={[styles.userBackground, { backgroundColor: theme.themeColor }]}> 
        <View style={styles.userContainer}>
          <Avatar.Image size={50} source={images.cl_7} />
          <Text style={[styles.userName, { color: theme.backgroundColor }]}>John Doe</Text>
        </View>
      </View>
      <View style={styles.drawerContainer}>
      {drawerItems.map((item, index) => (
        <TouchableOpacity
          key={index}
          style={[styles.drawerItem, { backgroundColor: theme.backColor }]}
        >
          <View style={styles.drawerItemContainer}>
            <Ionicons name={item.icon} size={22} color={theme.textColor} />
            <Text style={[styles.drawerLabel, { color: theme.textColor }]}>{item.label}</Text>
          </View>
        </TouchableOpacity>
      ))}
      </View>
      <View style={[styles.bottomDrawerSection, { borderTopColor: theme.themeColor }]}> 
        <TouchableOpacity style={styles.bottomContainer} onPress={handleLogout}>
          <Ionicons name="exit-outline" size={22} color={theme.textColor} />
          <Text style={[styles.bottomText, { color: theme.textColor }]}>Sign Out</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const drawerItems = [
  { label: 'Order', screen: 'Order', icon: 'disc-outline' },
];

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom: 10,
  },
  userBackground: {
    padding: 20,
    // alignItems: 'center',
    // justifyContent: 'center',
  },
  userContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userName: {
    marginLeft: 15,
    fontSize: 18,
    fontWeight: 'bold',
    textTransform: 'capitalize',
  },
  divider: {
    height: 2,
    marginVertical: 5,
    elevation: 3,
  },
  drawerContainer:{
    padding:10
  },
  drawerItem: {
    borderRadius: 8,
    marginVertical: 4,
    padding: 11,
  },
  drawerItemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  drawerLabel: {
    fontSize: 16,
    marginLeft: 15,
  },
  bottomDrawerSection: {
    padding: 15,
    borderTopWidth: 1,
  },
  bottomContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
  },
  bottomText: {
    marginLeft: 10,
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default DrawerContent;
