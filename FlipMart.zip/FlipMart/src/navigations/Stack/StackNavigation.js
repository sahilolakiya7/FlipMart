import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import DrawerNavigation from '../Drawer/DrawerNavigation';
import SplashScreen from '../../screens/Splash/SplashScreen';
import SigninScreen from '../../screens/Auth/Signin/SigninScreen';
import SignupScreen from '../../screens/Auth/Signup/SignupScreen';
import { useTheme } from '../../context/ThemeProvide';
import DetailsScreen from '../../screens/Product/DetailsScreen';
import Ionicons from "react-native-vector-icons/Ionicons";
const Stack = createNativeStackNavigator();

const CustomHeader = ({ title, navigation }) => {
  const { theme } = useTheme();

  return (
    <View style={[styles.headerContainer, { backgroundColor: theme.backgroundColor }]}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
       <Ionicons name={"arrow-back-outline"} size={32} color= {theme.textColor}  />
      </TouchableOpacity>
      <Text style={[styles.headerTitle, { color: theme.textColor }]}>{title}</Text>
    </View>
  );
};
const StackNavigation = () => {  
  const [splash, setSplash] = useState(true);
  useEffect(() => {
    setTimeout(() => {
      setSplash(false);
    }, 5000);
  }, []);

  const { theme } = useTheme();

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: theme.backgroundColor },
          headerTintColor: theme.textColor,
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        {splash && (
          <Stack.Screen 
            name="Splash" 
            component={SplashScreen} 
            options={{ headerShown: false }} 
          />
        )}
        <Stack.Screen 
          name="Signin" 
          component={SigninScreen} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="Signup" 
          component={SignupScreen} 
          options={{ headerShown: false }} 
        />
       
        <Stack.Screen 
          name="Drawer" 
          component={DrawerNavigation} 
          options={{ headerShown: false }} 
        />
        <Stack.Screen 
          name="Details" 
          component={DetailsScreen} 
          options={{ header: (props) => <CustomHeader {...props} title="Details" /> }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  ); 
};

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 60,
    paddingHorizontal: 10,
    elevation: 4,
  },
  backButton: {
    marginRight: 15,
  },
  backText: {
    fontSize: 20,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default StackNavigation;
