import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Platform } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Ionicons from "react-native-vector-icons/Ionicons";
import HomeScreen from "../../screens/Home/HomeScreen";
import { useTheme } from "../../context/ThemeProvide";
import ProductScreen from "../../screens/Product/ProductScreen";
import WishlistScreen from "../../screens/Whishlist/WhishlistScreen";
import CartScreen from "../../screens/Cart/CartScreen";
import ProfileScreen from "../../screens/Auth/Profile/ProfileScreen";

const Tab = createBottomTabNavigator();

// Custom Floating Cart Button
const CustomTabBarButton = ({ children, onPress }) => {
  const { theme } = useTheme();
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.9}
      style={styles.floatingButtonContainer}
    >
      <View style={[styles.floatingButton, { backgroundColor: theme.themeColor }]}>
        {children}
      </View>
    </TouchableOpacity>
  );
};

const BottomTabNavigator = () => {
  const { theme } = useTheme();

  return (
    <Tab.Navigator
      screenOptions={{
        tabBarShowLabel: false,
        tabBarStyle: [styles.tabBarStyle, { backgroundColor: theme.backgroundColor }],
      }}
    >
      {/* Home Tab */}
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused }) => (
            <View style={styles.iconContainer}>
              <Ionicons
                name={focused ? "home" : "home-outline"}
                size={26}
                color={focused ? theme.themeColor : theme.textColor}
              />
              <Text style={[styles.label, { color: focused ? theme.themeColor : theme.textColor }]}>
                Home
              </Text>
            </View>
          ),
        }}
      />

      {/* Product Tab */}
      <Tab.Screen
        name="Product"
        component={ProductScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused }) => (
            <View style={styles.iconContainer}>
              <Ionicons
                name={focused ? "grid" : "grid-outline"}
                size={26}
                color={focused ? theme.themeColor : theme.textColor}
              />
              <Text style={[styles.label, { color: focused ? theme.themeColor : theme.textColor }]}>
                Products
              </Text>
            </View>
          ),
        }}
      />

      {/* Floating Cart Button */}
      <Tab.Screen
        name="Cart"
        component={CartScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused }) => (
            <Ionicons name={focused ? "cart" : "cart-outline"} size={32} color={focused ? theme.whiteColor : theme.whiteColor} />
          ),
          tabBarButton: (props) => <CustomTabBarButton {...props} />,
        }}
      />

      {/* Wishlist Tab */}
      <Tab.Screen
        name="Wishlist"
        component={WishlistScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused }) => (
            <View style={styles.iconContainer}>
              <Ionicons
                name={focused ? "heart" : "heart-outline"}
                size={26}
                color={focused ? theme.themeColor : theme.textColor}
              />
              <Text style={[styles.label, { color: focused ? theme.themeColor : theme.textColor }]}>
                Wishlist
              </Text>
            </View>
          ),
        }}
      />

      {/* Profile Tab */}
      <Tab.Screen
        name="ProfileTab"
        component={ProfileScreen}
        options={{
          headerShown: false,
          tabBarIcon: ({ focused }) => (
            <View style={styles.iconContainer}>
              <Ionicons
                name={focused ? "person-circle" : "person-circle-outline"}
                size={26}
                color={focused ? theme.themeColor : theme.textColor}
              />
              <Text style={[styles.label, { color: focused ? theme.themeColor : theme.textColor }]}>
                Users
              </Text>
            </View>
          ),
        }}
      />
    </Tab.Navigator>
  );
};

const styles = StyleSheet.create({
  tabBarStyle: {
    height: Platform.OS === "ios" ? 75 : 65,
    position: "absolute",
    elevation: 5,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: -2 },
    shadowRadius: 5,
    left: 0,  
    right: 0, 
    bottom: 0, 
    paddingTop:12,
  },
  iconContainer: {
    alignItems: "center",
    justifyContent: "center",
    width: 70, 
  },
  label: {
    fontSize: 12,
    marginTop: 4,
    fontWeight: "600",
  },
  floatingButtonContainer: {
    top: -30,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.25,
    shadowOffset: { width: 0, height: 5 },
    shadowRadius: 6,
    elevation: 5,
  },
  floatingButton: {
    height: 70,
    width: 70,
    borderRadius: 35,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 3,
    borderColor: "#fff",
  },
});

export default BottomTabNavigator;
