import {ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import Layout from '../../../components/Layout/Layout';
import { useTheme } from '../../../context/ThemeProvide';
import UserComponent from '../../../components/User/UserComponent';

const ProfileScreen = () => {
  const { theme } = useTheme();
      const [data, setData] = useState([]);
  
      useEffect(() => {
          fetchData();
      }, []);
      const fetchData = async () => {
          try {
              const response = await fetch('https://fakestoreapi.com/users');
              const json = await response.json();
              setData(json);
          } catch (error) {
          }
      };
  return (
    <Layout>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ backgroundColor: theme.backgroundColor }}>
        <UserComponent dummyProducts={data} title={"Popular"}  />
      </ScrollView>
    </Layout>
  );
};
export default ProfileScreen;

