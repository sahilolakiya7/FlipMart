import { View, StyleSheet, ScrollView } from 'react-native'
import React, { useState } from 'react'
import { Text  } from 'react-native-paper';
import { useTheme } from '../../../context/ThemeProvide';
import InputComponent from '../../../components/InputComponent/InputComponent';
import ButtonComponent from '../../../components/Buttons/ButtonComponent';
const ResetPasswordScreen = () => {
    const [password, setPassword] = useState('');
    const [passwordSecure, setPasswordSecure] = useState(true);
    const [errorPassword, setErrorPassword] = useState('');

    const [newPassword, setNewPassword] = useState('');
    const [newPasswordSecure, setNewPasswordSecure] = useState(true);
    const [errorNewPassword, setErrorNewPassword] = useState('');

    const [reNewPassword, setReNewPassword] = useState('');
    const [reNewPasswordSecure, setReNewPasswordSecure] = useState(true);
    const [errorReNewPassword, setErrorReNewPassword] = useState('');

    const {theme} = useTheme();
    const handleSubmit = () => {
      if(password == "" || newPassword == "" || reNewPassword == ""){
        {password == "" ? setErrorPassword("Please Enter Current Password") : setErrorPassword('')}
        {newPassword == "" ? setErrorNewPassword("Please Enter New Password") : setErrorNewPassword('')}
        {reNewPassword == "" ? setErrorReNewPassword("Enter Re-enter Password") : setErrorReNewPassword('')}
      }else{
        console.log('handleSubmit')
        if(newPassword !== reNewPassword){
            setErrorReNewPassword("Not same as New Password");
            setErrorPassword('');            
            setErrorNewPassword('');
        }else{
            setPassword('');
            setErrorPassword('');
            setNewPassword('');
            setErrorNewPassword('');
            setReNewPassword('');
            setErrorReNewPassword('');
        }
      }
    }
    return (
      <ScrollView contentContainerStyle={{ backgroundColor: theme.backgroundColor,flexGrow: 1 }}>
        <View style={{...styles.container}}>
          <View style={{...styles.bottomContainer}}>
            <View style={{...styles.headerContainer}}>
              <Text variant="titleLarge" 
                style={{
                  fontWeight:'bold',
                  color:theme.themeColor
                }}>Change Password</Text>
                {/*  */}
              <Text variant="titleSmall" 
                style={{
                  color:theme.textColor
                }}>to Easyly chage password and enjoy it</Text>
            </View>
              {/*  */}
              <View style={{...styles.inputContainer}}>
              <InputComponent 
                label={"Current Password"}
                icon={passwordSecure ? "eye" : "eye-off"}
                onPressIcon={()=>setPasswordSecure(!passwordSecure)}
                value={password}
                onChangeText={(value)=>setPassword(value)}
                secureTextEntry={passwordSecure}
                />
                {errorPassword !="" && <Text variant="bodyMedium" style={{color:theme.COLORS.error}}>{errorPassword}</Text>}
                {/*  */}
                <InputComponent 
                    label={"New Password"}
                    icon={newPasswordSecure ? "eye" : "eye-off"}
                    onPressIcon={()=>setNewPasswordSecure(!newPasswordSecure)}
                    value={newPassword}
                    onChangeText={(value)=>setNewPassword(value)}
                    secureTextEntry={newPasswordSecure}
                />
                {errorNewPassword !="" && <Text variant="bodyMedium" style={{color:theme.COLORS.error}}>{errorNewPassword}</Text>}
                <InputComponent 
                    label={"Re-enter New Password"}
                    icon={reNewPasswordSecure ? "eye" : "eye-off"}
                    onPressIcon={()=>setReNewPasswordSecure(!reNewPasswordSecure)}
                    value={reNewPassword}
                    onChangeText={(value)=>setReNewPassword(value)}
                    secureTextEntry={reNewPasswordSecure}
                />
                {errorReNewPassword !="" && <Text variant="bodyMedium" style={{color:theme.COLORS.error}}>{errorReNewPassword}</Text>}
                {/*  */}
                <ButtonComponent 
                  mode={"contained"}
                  title={"Chage Password"}
                  icon={"lock-open"}
                  buttonColor={theme.themeColor}
                  onPress={()=>handleSubmit()}
                />
              </View>
              <View style={{flex:3}}></View>
          </View>
        </View>
      </ScrollView>
    )
  }
  
  const styles = StyleSheet.create({
    container:{
      flex:1,
      padding:10,
    },
    topContainer:{
      flex:1,
      justifyContent:'center',
      alignItems:'center',
    },
    imageLogo:{
      height:200,
      width:250,
      resizeMode:'contain'
    },
    bottomContainer:{
      flex:2,
      justifyContent:'space-between'
    },
    headerContainer:{
      flex:1,
    },
    text: {
      fontSize: 20,
      height:60
    },
    inputContainer:{
      flex:2,
      justifyContent:'space-evenly',
    },
  });

export default ResetPasswordScreen