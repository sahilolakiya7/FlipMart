import { View, StyleSheet, Image, TouchableOpacity, ScrollView, Alert } from 'react-native';
import React, { useState } from 'react';
import { Text } from 'react-native-paper';
import { useTheme } from '../../../context/ThemeProvide';
import InputComponent from '../../../components/InputComponent/InputComponent';
import ButtonComponent from '../../../components/Buttons/ButtonComponent';
import { useNavigation } from '@react-navigation/native';
import images from '../../../../assets/animation/images';
import { auth } from '../../../../firebaseConfig'; // ✅ your Firebase config
import { signInWithEmailAndPassword } from 'firebase/auth'; // ✅ import the auth method

const SigninScreen = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordSecure, setPasswordSecure] = useState(true);
  const [errorEmail, setErrorEmail] = useState('');
  const [errorPassword, setErrorPassword] = useState('');
  const navigation = useNavigation();
  const { theme } = useTheme();

  const handleSubmit = async () => {
    setErrorEmail('');
    setErrorPassword('');

    if (email === '' || password === '') {
      setErrorEmail(email === '' ? 'Please Enter Email Id' : '');
      setErrorPassword(password === '' ? 'Please Enter Password' : '');
      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      console.log('User signed in:', userCredential.user);
      navigation.navigate('Drawer');
    } catch (error) {
      console.log('Login error:', error.message);
      if (error.code === 'auth/invalid-email') {
        setErrorEmail('Invalid email format');
      } else if (error.code === 'auth/user-not-found') {
        setErrorEmail('No account found for this email');
      } else if (error.code === 'auth/wrong-password') {
        setErrorPassword('Incorrect password');
      } else {
        Alert.alert('Login Failed', error.message);
      }
    }
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
        <View style={styles.topContainer}>
          <Image source={images.App_logo} style={styles.imageLogo} />
        </View>
        <View style={styles.bottomContainer}>
          <View style={styles.headerContainer}>
            <Text variant="headlineSmall" style={{ fontWeight: 'bold', color: theme.themeColor }}>
              Welcome Back
            </Text>
            <Text variant="titleMedium" style={{ color: theme.textColor }}>
              Login with your account to continue.
            </Text>
          </View>
          <View style={styles.inputContainer}>
            <InputComponent label="Email Id" icon="email" value={email} onChangeText={setEmail} />
            {errorEmail !== '' && (
              <Text variant="bodyMedium" style={{ color: theme.COLORS.error }}>{errorEmail}</Text>
            )}
            <InputComponent
              label="Password"
              icon={passwordSecure ? 'eye' : 'eye-off'}
              onPressIcon={() => setPasswordSecure(!passwordSecure)}
              value={password}
              onChangeText={setPassword}
              secureTextEntry={passwordSecure}
            />
            {errorPassword !== '' && (
              <Text variant="bodyMedium" style={{ color: theme.COLORS.error }}>{errorPassword}</Text>
            )}
            <ButtonComponent
              mode="contained"
              title="SignIn"
              icon="login"
              borderColor={theme.themeColor}
              buttonColor={theme.themeColor}
              textColor={theme.whiteColor}
              onPress={handleSubmit}
            />
            <ButtonComponent
              mode="elevated"
              title="SignUp"
              icon="account-plus"
              borderColor={theme.themeColor}
              buttonColor={theme.backColor}
              textColor={theme.themeColor}
              onPress={() => navigation.navigate('Signup')}
            />
          </View>
          <View style={{ flex: 1 }}></View>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10 },
  topContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  imageLogo: { height: 200, width: 250, resizeMode: 'contain' },
  bottomContainer: { flex: 2, justifyContent: 'space-between' },
  headerContainer: { flex: 1 },
  inputContainer: { flex: 2, justifyContent: 'space-evenly' },
});

export default SigninScreen;
