import { View, StyleSheet, Image, ScrollView, Alert } from 'react-native';
import React, { useState } from 'react';
import { Text } from 'react-native-paper';
import { useTheme } from '../../../context/ThemeProvide';
import InputComponent from '../../../components/InputComponent/InputComponent';
import ButtonComponent from '../../../components/Buttons/ButtonComponent';
import { useNavigation } from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { showMessage } from 'react-native-flash-message';
import images from '../../../../assets/animation/images';

import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../../../firebaseConfig';
// import { auth } from '../../../config/firebaseConfig'; // ✅ Make sure this path is correct

const SignupScreen = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordSecure, setPasswordSecure] = useState(true);
  const [errorEmail, setErrorEmail] = useState('');
  const [errorPassword, setErrorPassword] = useState('');
  const { theme } = useTheme();
  const navigation = useNavigation();

  const handleSubmit = async () => {
    setErrorEmail('');
    setErrorPassword('');

    if (email === '' || password === '') {
      setErrorEmail(email === '' ? 'Please Enter Email Id' : '');
      setErrorPassword(password === '' ? 'Please Enter Password' : '');
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      console.log('User registered:', user);

      showMessage({
        message: 'Signup Successful!',
        type: 'success',
        backgroundColor: theme.themeColor,
        color: theme.backgroundColor,
        icon: () => <Ionicons name="checkmark-circle" size={20} color={theme.backgroundColor} />,
      });

      setEmail('');
      setPassword('');
      navigation.navigate('Signin');
    } catch (error) {
      console.error('Signup Error:', error.message);
      if (error.code === 'auth/email-already-in-use') {
        setErrorEmail('Email already in use');
      } else if (error.code === 'auth/invalid-email') {
        setErrorEmail('Invalid email format');
      } else if (error.code === 'auth/weak-password') {
        setErrorPassword('Password should be at least 6 characters');
      } else {
        showMessage({
          message: 'Signup Failed',
          description: error.message,
          type: 'danger',
          backgroundColor: theme.COLORS.error,
          color: theme.whiteColor,
        });
      }
    }
  };

  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
      <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
        <View style={styles.topContainer}>
          <Image source={images.App_logo} style={styles.imageLogo} />
        </View>
        <View style={styles.bottomContainer}>
          <View style={styles.headerContainer}>
            <Text variant="headlineSmall" style={{ fontWeight: 'bold', color: theme.themeColor }}>
              Sign Up
            </Text>
            <Text variant="titleMedium" style={{ color: theme.textColor }}>
              Create your account to continue.
            </Text>
          </View>

          <View style={styles.inputContainer}>
            <InputComponent label="Email Id" icon="email" value={email} onChangeText={setEmail} />
            {errorEmail !== '' && (
              <Text variant="bodyMedium" style={{ color: theme.COLORS.error }}>
                {errorEmail}
              </Text>
            )}

            <InputComponent
              label="Password"
              icon={passwordSecure ? 'eye' : 'eye-off'}
              onPressIcon={() => setPasswordSecure(!passwordSecure)}
              value={password}
              onChangeText={setPassword}
              secureTextEntry={passwordSecure}
            />
            {errorPassword !== '' && (
              <Text variant="bodyMedium" style={{ color: theme.COLORS.error }}>
                {errorPassword}
              </Text>
            )}

            <ButtonComponent
              mode="contained"
              title="Sign Up"
              icon="account-plus"
              borderColor={theme.themeColor}
              buttonColor={theme.themeColor}
              textColor={theme.whiteColor}
              onPress={handleSubmit}
            />

            <ButtonComponent
              mode="elevated"
              title="Sign In"
              icon="login"
              borderColor={theme.themeColor}
              buttonColor={theme.backColor}
              textColor={theme.themeColor}
              onPress={() => navigation.navigate('Signin')}
            />
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10 },
  topContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  imageLogo: { height: 200, width: 250, resizeMode: 'contain' },
  bottomContainer: { flex: 2, justifyContent: 'space-between' },
  headerContainer: { flex: 1 },
  inputContainer: { flex: 2, justifyContent: 'space-evenly' },
});

export default SignupScreen;
