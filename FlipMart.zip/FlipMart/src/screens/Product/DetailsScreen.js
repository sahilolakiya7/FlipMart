import React, { useEffect, useState } from 'react';
import { FlatList, View, SafeAreaView, BackHandler, ActivityIndicator } from 'react-native';
import DetailsHeader from '../../components/ProductDetails/DetailsHeader';
import ImageComponent from '../../components/Banner/ImageComponent';
import DetailsComponent from '../../components/ProductDetails/DetailsComponent';
import { useTheme } from '../../context/ThemeProvide';

const DetailsScreen = ({ route, navigation }) => {
  const { productId } = route.params;
  const [product, setProduct] = useState(null);
  const { theme } = useTheme();

  useEffect(() => {
    fetchProductDetails();

    const backAction = () => {
      navigation.goBack();
      return true;
    };

    const backHandler = BackHandler.addEventListener('hardwareBackPress', backAction);
    return () => backHandler.remove();
  }, [productId]);

  const fetchProductDetails = async () => {
    try {
      const response = await fetch(`https://fakestoreapi.com/products/${productId}`);
      const data = await response.json();
      setProduct(data);
    } catch (error) {
      console.error('Failed to fetch product details:', error);
    }
  };

  if (!product) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: theme.backgroundColor }}>
        <ActivityIndicator size="large" color="#000" />
      </View>
    );
  }

  const sections = [
    { key: 'header', component: <DetailsHeader item={product} /> },
    { key: 'image', component: <ImageComponent bannerImage={product.image} /> },
    { key: 'details', component: <DetailsComponent item={product} /> },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.backgroundColor }}>
      <FlatList
        data={sections}
        keyExtractor={(item) => item.key}
        renderItem={({ item }) => item.component}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
    </SafeAreaView>
  );
};

export default DetailsScreen;
