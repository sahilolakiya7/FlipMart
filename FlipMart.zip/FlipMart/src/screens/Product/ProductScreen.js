import { ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import Layout from '../../components/Layout/Layout';
import CategoryComponent from '../../components/Category/CategoryComponent';
import ProductComponent from '../../components/Product/ProductComponent';
import SearchInput from '../../components/Search/SearchInput';
import { useTheme } from '../../context/ThemeProvide';


const ProductScreen = () => {
   const { theme } = useTheme();
         const [data, setData] = useState([]);
     
         useEffect(() => {
             fetchData();
         }, []);
   
         const fetchData = async () => {
             try {
                 const response = await fetch('https://fakestoreapi.com/products');
                 const json = await response.json();
                 setData(json);
             } catch (error) {
             }
         };
  return (
    <Layout>
      <SearchInput />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ backgroundColor: theme.backgroundColor }}>
        <CategoryComponent />
        <ProductComponent dummyProducts={data}  renderSuccess={true} />
      </ScrollView>
    </Layout>
  );
};

export default ProductScreen;
