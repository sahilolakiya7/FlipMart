import { StatusBar } from 'react-native'
import React from 'react'
import StackNavigation from '../navigations/Stack/StackNavigation'
import { useTheme } from '../context/ThemeProvide'
import FlashMessage from "react-native-flash-message";
// import KeepAwake from 'react-native-keep-awake';

const MainScreen = () => {
  // KeepAwake.activate();
  const {theme,themeMode} = useTheme();
  return (
    <>
    <StatusBar 
      backgroundColor={theme.backgroundColor}
      barStyle={themeMode==="light"?"dark-content":"light-content"}
    />
    <StackNavigation />
    <FlashMessage position="top" />
    </>
  )
}

export default MainScreen