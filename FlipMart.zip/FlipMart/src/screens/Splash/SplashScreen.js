  import { View, StyleSheet, Image } from 'react-native'
  import React from 'react'
  import { useTheme } from '../../context/ThemeProvide';
  import images from '../../../assets/animation/images';

  const SplashScreen = () => {
    const { theme } = useTheme();
    return (
      <View style={[styles.container,{backgroundColor:theme.backgroundColor}]}>
        <Image source={images.App_logo} style={styles.image}/>
      </View>
    )
  }

const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent:'center',
        alignItems:'center',
    },
    image:{
        height:'30%',
        width:'70%',
        resizeMode:'contain',
        marginBottom:10,
    },
    text:{
      marginTop:5,
      fontSize:24,
      fontWeight:'bold',
      textTransform:'uppercase',
    }

});

export default SplashScreen