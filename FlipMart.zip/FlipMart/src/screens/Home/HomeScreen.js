import {ScrollView } from 'react-native';
import React, { useEffect, useState } from 'react';
import Layout from '../../components/Layout/Layout';
import SearchComponent from '../../components/Search/SearchComponent';
import SliderComponent from '../../components/Banner/SliderComponent';
import CategoryComponent from '../../components/Category/CategoryComponent';
import PopularComponent from '../../components/PopularProduct/PopularComponent';
import { useTheme } from '../../context/ThemeProvide';
const HomeScreen = () => {
  const { theme } = useTheme();
      const [data, setData] = useState([]);
  
      useEffect(() => {
          fetchData();
      }, []);

      const fetchData = async () => {
          try {
              const response = await fetch('https://fakestoreapi.com/products');
              const json = await response.json();
              setData(json);
          } catch (error) {
          }
      };
  return (
    <Layout>
      <SearchComponent title="Search for..." />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ backgroundColor: theme.backgroundColor }}>
        <SliderComponent />
        <CategoryComponent  />
        <PopularComponent dummyProducts={data} title={"Popular"}  />
      </ScrollView>
    </Layout>
  );
};
export default HomeScreen;
