import { View, Text, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
import React, { useEffect, useState } from 'react';
import Layout from '../../components/Layout/Layout';
import { useTheme } from '../../context/ThemeProvide';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import ItemComponent from '../../components/Item/ItemComponent';
import { Divider } from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';

const CartScreen = () => {
  const [cartItems, setCartItems] = useState([]);
  const [shipping, setShipping] = useState(50);
  const [tax, setTax] = useState(20);
  const [loading, setLoading] = useState(true);
  const { theme } = useTheme();
  const navigation = useNavigation();
  console.log(cartItems,"cartItems")

  useEffect(() => {
    fetchCartData();
  }, []);

  const fetchCartData = async () => {
    try {
      setLoading(true);
      // Fetch cart of userId 1
      const cartRes = await fetch('https://fakestoreapi.com/carts/user/1');
      const cartData = await cartRes.json();

      if (cartData.length === 0) return;

      const latestCart = cartData[cartData.length - 1];
      const productPromises = latestCart.products.map(async (prod) => {
        const productRes = await fetch(`https://fakestoreapi.com/products/${prod.productId}`);
        const productData = await productRes.json();
        return {
          ...productData,
          qty: prod.quantity,
        };
      });

      const fullProducts = await Promise.all(productPromises);
      setCartItems(fullProducts);
    } catch (err) {
      console.error('Cart Fetch Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const getTotal = () => {
    return cartItems.reduce(
      (acc, item) => acc + item.price * item.qty,
      0
    );
  };

  return (
    <Layout>
      <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
        <ScrollView showsVerticalScrollIndicator={false}>
          {loading ? (
            <ActivityIndicator size="large" color={theme.themeColor} style={{ marginTop: 50 }} />
          ) : cartItems.length > 0 ? (
            cartItems.map((item, index) => (
              <ItemComponent cart={'cart'} item={item} key={index} />
            ))
          ) : (
            <View style={styles.emptyCartContainer}>
              <View style={styles.emptyCartBox}>
                <Text style={styles.emptyCartText}>Cart is Empty</Text>
              </View>
            </View>
          )}

          {!loading && cartItems.length > 0 && (
            <View style={styles.bottomContainer}>
              <View style={styles.subTotalContainer}>
                <Text style={[styles.subTotalText, { color: theme.textColor }]}>Sub Total:</Text>
                <Text style={[styles.subTotalText, { color: theme.textColor }]}>
                  Rs. {getTotal().toFixed(2)}
                </Text>
              </View>

              <Divider style={{ backgroundColor: theme.borderColor, height: 2 }} />

              <View style={styles.subTotalContainer}>
                <Text style={[styles.subTotalText, { color: theme.textColor }]}>Shipping:</Text>
                <Text style={[styles.subTotalText, { color: theme.textColor }]}>Rs. {shipping}</Text>
              </View>
              <View style={styles.subTotalContainer}>
                <Text style={[styles.subTotalText, { color: theme.textColor }]}>Tax:</Text>
                <Text style={[styles.subTotalText, { color: theme.textColor }]}>Rs. {tax}</Text>
              </View>

              <Divider style={{ backgroundColor: theme.borderColor, height: 2 }} />

              <View style={styles.addToCartContainer}>
                <View style={styles.priceContainer}>
                  <Text style={[styles.subTotalText, { color: theme.textColor }]}>Grand Total</Text>
                  <Text style={[styles.priceText, { color: theme.themeColor }]}>
                    Rs. {(getTotal() + shipping + tax).toFixed(2)}
                  </Text>
                </View>
                <TouchableOpacity
                  style={{
                    ...styles.addToCartButtonContainer,
                    backgroundColor: theme.themeColor,
                  }}
                >
                  <FontAwesome5 name="check-circle" size={18} color={theme.whiteColor} />
                  <Text style={[styles.addBtnText, { color: theme.whiteColor }]}>Checkout</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </ScrollView>
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingVertical: 5,
  },
  emptyCartContainer: {
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyCartBox: {
    height: 40,
    width: '50%',
    backgroundColor: 'grey',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    elevation: 4,
  },
  emptyCartText: {
    fontSize: 14,
    color: 'white',
    fontWeight: 'bold',
  },
  bottomContainer: {
    padding: 10,
  },
  subTotalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 15,
    paddingHorizontal: 10,
  },
  subTotalText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  addToCartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    alignItems: 'center',
  },
  priceContainer: {
    width: '60%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 5,
  },
  priceText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  addToCartButtonContainer: {
    paddingHorizontal: 10,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 10,
  },
  addBtnText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 10,
    letterSpacing: 1,
  },
});

export default CartScreen;
