import { View, Text, StyleSheet, ScrollView } from 'react-native';
import React, { useState } from 'react';
import Layout from '../../components/Layout/Layout';
import ItemComponent from '../../components/Item/ItemComponent';
import { useTheme } from '../../context/ThemeProvide';
import images from '../../../assets/animation/images';

const dummyData = [
  { id: 1,image:images.cl_12,category:"VSPCreation", name: 'Formal Regular Women Top', price: 299, qty: 2, no_of_pc: 1 },
  { id: 2,image:images.cl_13,category:"KOTTY ", name: 'Pack of 2 Solid Women Multicolor Basic Shorts', price: 245, qty: 1, no_of_pc: 2 },
  { id: 3,image:images.cl_16,category:"Palazzos ", name: 'Casual Puff Sleeves Floral Print Women Black Top', price: 245, qty: 3, no_of_pc: 1 },
];

const WhishlistScreen = () => {
  const { theme } = useTheme();
  const [wishItems, setWishItems] = useState(dummyData);

  return (
    <Layout>
      <View style={[styles.container,{ backgroundColor: theme.backgroundColor }]}>
        <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.emptyContainer}>
             
             <Text style={{ fontSize: 14, color: theme.COLORS.grey1, fontWeight: 'bold' }}>
               No Items Available Yet...
             </Text>
           </View>
        </ScrollView>
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingVertical: 5,
  },
  emptyContainer: {
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default WhishlistScreen;
