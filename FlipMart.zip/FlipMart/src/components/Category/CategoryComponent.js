import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeProvide';
const categoryData = [
    'All', 'Shoes', 'Watches', 'Headphones', 'Bags', 'Glasses'
];
const CategoryComponent = () => {
    const [selectedCategory, setSelectedCategory] = useState('All');
    const { theme } = useTheme();

    const handleFilter = (value) => {
        setSelectedCategory(value);
        console.log(`Selected Category: ${value}`);
    };
    return (
        <View style={styles.container}>
            <FlatList 
                data={categoryData}
                renderItem={({ item }) => (
                    <View style={styles.subContainer}>
                        <TouchableOpacity 
                            style={[styles.categoryContainer, { backgroundColor: selectedCategory === item ? theme.themeColor : theme.backColor }]}
                            onPress={() => handleFilter(item)}
                        >
                            <Text style={[styles.textTitle, { color: selectedCategory === item ? theme.whiteColor : theme.textColor }]}>
                                {item}
                            </Text>
                        </TouchableOpacity>
                    </View>
                )}
                keyExtractor={(item, index) => `${item}${index}`}
                horizontal={true}
                showsHorizontalScrollIndicator={false}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        height: 50,
        flexDirection: 'row',
        paddingHorizontal: 5,
    },
    subContainer: {
        height: '100%',
        paddingVertical: 5,
        paddingHorizontal: 5,
    },
    categoryContainer: {
        flex: 1,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 10,
        borderRadius: 5,
        elevation: 5,
    },
    textTitle: {
        width: '100%',
        marginLeft: 5,
        fontSize: 18,
        fontWeight: 'bold',
        textTransform: 'capitalize',
    },
});

export default CategoryComponent;
