import { View, StyleSheet, Dimensions } from 'react-native'
import React from 'react'
import { FlatListSlider } from 'react-native-flatlist-slider'
import { useTheme } from '../../context/ThemeProvide';
const images = [
    {
     banner:require('../../../assets/animation/images/banner_2.png'),
    },
   {
     banner:require('../../../assets/animation/images/banner_3.png'),
   },
   {
    banner:require('../../../assets/animation/images/banner_4.png'),
  }
   ]

const { width } = Dimensions.get('screen');

const SliderComponent = () => {
    const { theme } = useTheme();

    return (
        <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
            <View style={styles.banerContainer}>
                <FlatListSlider
                    data={images}
                    imageKey={'banner'}
                    timer={3000}
                    onPress={() => ""}
                    height={"100%"}
                    indicatorContainerStyle={{ bottom: 10 }}
                    indicatorActiveColor={theme?.themeColor}
                    indicatorInActiveColor={theme?.borderColor}
                    indicatorActiveWidth={10}
                    animation
                    local
                />
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        height: 200,
        width: width,
    },
    banerContainer: {
        height: '90%',
        width: '100%',
    },
});

export default SliderComponent;
