import { View, StyleSheet, Image,Dimensions } from 'react-native'
import React from 'react'
const {width} = Dimensions.get('screen');
const ImageComponent = (props) => {    
  return (
    <View style={styles.container}>
        <View style={styles.banerContainer}>
            <View style={styles.imageContainer}>
                <Image source={{uri:props?.bannerImage}} style={styles.bannerImage}/> 
            </View>        
        </View>
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        height:230,
        width:width,
    },
    banerContainer:{
        height:'90%',
        width:'100%',
    }, 
    imageContainer:{
        height:'100%',
        width:'100%',
    },  
    bannerImage:{
        height:'140%',
        width:width,
        resizeMode:'contain',
        backgroundColor:'#fff'
    },
    indicatorContainer:{
        height:'10%',
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center',

    },
    dot:{
        height:10,
        width:10,
        borderRadius:25,
        borderWidth:1,
        marginRight:5,
    },
});

export default ImageComponent