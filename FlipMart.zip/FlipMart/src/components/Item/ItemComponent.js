import { View, Text, StyleSheet, Image, TouchableOpacity, Alert } from 'react-native';
import React, { useState } from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useTheme } from '../../context/ThemeProvide';
import IncrementDecrement from '../IncrementDecrement/IncrementDecrement';
import AddToCartButton from '../Buttons/AddToCartButton';

const ItemComponent = (props) => {
  const { item } = props;
  const [qty, setQty] = useState(item?.qty || 1);
  const { theme } = useTheme();

  const handleRemove = (id) => {
    Alert.alert('Warning', 'Are You Sure To Remove..?', [
      {
        text: 'Yes',
        onPress: () => {
          console.log('Removed item with ID:', id);
        },
      },
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.topContainer}>
        <View style={{ ...styles.itemContainer, backgroundColor: theme.backColor }}>
          <View style={styles.imageContainer}>
            <Image source={{uri:item.image}} style={styles.image} />
          </View>
          <View style={styles.itemDetailsContainer}>
            <View style={styles.itemTitle}>
              <Text style={{ fontSize: 16,width:'90%',color:theme.textColor }}>
              {item.title.length > 40 ? `${item.title.slice(0, 40)}...` : item.title}
              </Text>
              {props?.cart || props?.wish ? (
                <TouchableOpacity onPress={() => handleRemove(item.id)}>
                  <Ionicons name='close-circle-outline' color={theme.textColor } size={18} />
                </TouchableOpacity>
              ) : null}
            </View>
            <Text style={{ fontSize: 14,color:theme.textColor  }}>{item.category}</Text>
            <View style={styles.itemTitle}>
              <Text style={{ fontSize: 16, fontWeight: 'bold', color: theme.textColor }}>{`Rs. ${item.price}`}
                {/* {props?.cart && <Text style={{ fontSize: 12,color:theme.textColor  }}>{` ( MOQ - ${item.no_of_pc} )`}</Text>} */}
              </Text>

              {props?.cart && <IncrementDecrement qty={qty} setQty={setQty} existQty={item.qty} item={item} />}
              {props?.wish && <AddToCartButton Button item={item} qty={qty} setQty={setQty} />}
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingVertical: 5,
  },
  topContainer: {
    paddingHorizontal: 10,
  },
  itemContainer: {
    height: 120,
    flexDirection: 'row',
    elevation: 5,
    borderRadius: 10,
  },
  imageContainer: {
    height: '100%',
    width: '30%',
  },
  image: {
    height: '100%',
    width: '100%',
    resizeMode: 'contain',
    backgroundColor:'#fff',
    borderTopLeftRadius:10,
    borderBottomLeftRadius:10

  },
  itemDetailsContainer: {
    flex: 1,
    justifyContent: 'space-between',
    padding: 10,
  },
  itemTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
});

export default ItemComponent;