import { View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import React from 'react';
import { Avatar, Badge } from 'react-native-paper';
import Ionicons from 'react-native-vector-icons/Ionicons';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import { useTheme } from '../../../context/ThemeProvide';
import { useNavigation } from '@react-navigation/native';
import images from '../../../../assets/animation/images';

const HeaderComponent = () => {
    const { theme } = useTheme();
    const navigation = useNavigation();

    const cartItems = [{ id: 1 }, { id: 2 }, { id: 3 }];

    return (
        <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
            <View style={styles.leftContainer}>
                <TouchableOpacity onPress={navigation.openDrawer}>
                    <Ionicons name="grid" size={22} color={theme?.themeColor} />
                </TouchableOpacity>
            </View>
            <View style={styles.middleContainer}>
                <Image 
                    source={images.App_logo} 
                    style={styles.logo} 
                />
            </View>
            <View style={styles.rightContainer}>
                <TouchableOpacity style={styles.rightIcon} onPress={() => navigation.navigate("Cart")}>
                    <SimpleLineIcons color={theme?.textColor} name='basket' size={22} />
                    <Badge style={{
                        backgroundColor: theme?.themeColor,
                        position: 'absolute', 
                        top: -6, left: 15
                    }}>{cartItems.length}</Badge>
                </TouchableOpacity>
                <Avatar.Image 
                    size={32} 
                    source={images.cl_7} 
                    style={{ borderColor: theme.themeColor }}
                />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        height: 50,
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 10,
        elevation: 2,
    },
    leftContainer: {
        width: '30%',
    },
    middleContainer: {
        height: '100%',
        width: '30%',
    },
    logo: {
        height: '100%',
        width: '100%',
        resizeMode: 'contain',
    },
    rightContainer: {
        width: '30%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
    rightIcon: {
        marginHorizontal: 20,
    },
});

export default HeaderComponent;
