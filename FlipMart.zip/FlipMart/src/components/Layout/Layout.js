import { View} from 'react-native'
import React from 'react'
import HeaderComponent from './Header/HeaderComponent'
import { useTheme } from '../../context/ThemeProvide'

const Layout = ({children}) => {
  const {theme} = useTheme();
  return (
    <View style={{flex:1,backgroundColor:theme.appColor}}>
        <HeaderComponent />
        {children}
    </View>
  )
}

export default Layout