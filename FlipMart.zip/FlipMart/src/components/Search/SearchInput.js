import { View, TextInput, StyleSheet } from 'react-native';
import React, { useState } from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useTheme } from '../../context/ThemeProvide';

const SearchInput = () => {
    const { theme } = useTheme();
    const [search, setSearch] = useState('');
    return (
        <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>            
            <View style={[styles.searchContainer, { borderColor: theme.themeColor }]}>            
                <Ionicons name="search" size={20} style={[styles.searchIcon,{color:theme.textColor}]} />
                <TextInput 
                   style={[styles.searchText,{color:theme.textColor}]}
                    placeholder="Search for..."
                    value={search}
                    onChangeText={(value) => setSearch(value)}
                    autoCapitalize='none'
                    placeholderTextColor={theme.textColor}
                />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        height: 55,
        width: '100%',
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
    searchContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderRadius:10,
        paddingHorizontal: 10,
        paddingVertical: 5,
    },
    searchText: {
        flex: 1,
        height: 40,
        marginLeft: 10,
    },
});

export default SearchInput;
