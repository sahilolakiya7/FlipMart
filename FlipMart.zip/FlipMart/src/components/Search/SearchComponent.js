import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import React from 'react'
import Ionicons from 'react-native-vector-icons/Ionicons'
import { useNavigation } from '@react-navigation/native'
import { useTheme } from '../../context/ThemeProvide'

const SearchComponent = (props) => {
    const navigation = useNavigation();
    const {theme} = useTheme();
  return (
    <View style={[styles.container,{backgroundColor:theme?.backgroundColor}]}>
      <TouchableOpacity style={[styles.searchContainer,{
        borderColor:theme?.themeColor,
      }]} 
      onPress={()=>navigation.navigate('Product')}
      >
        <Ionicons name="search" size={20} style={[styles.searchIcon,{color:theme.textColor}]} />
        <Text style={[styles.searchText,{color:theme.textColor}]}>{props.title}</Text>
      </TouchableOpacity>
    </View>
  )
}
 const styles = StyleSheet.create({
    container:{
        height:55,
        width:'100%',
        paddingHorizontal:10,
        paddingVertical:8,
    },
    searchContainer:{
        flex:1,
        flexDirection:'row',
        alignItems:'center',
        borderWidth:1,
        paddingHorizontal:10,
        paddingVertical:5,
        borderRadius:5,
    },
    searchText:{
        marginLeft:10,
    },
 });

export default SearchComponent