import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import React, { useState } from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useTheme } from '../../context/ThemeProvide';
import { useNavigation } from '@react-navigation/native';

const ProductComponent = (props) => {
    const { dummyProducts } = props;
    const { theme } = useTheme();
    const navigation = useNavigation();
    const [wishlist, setWishlist] = useState([]);
    const toggleWishlist = (id) => {
        setWishlist(prevWishlist =>
            prevWishlist.includes(id) ? prevWishlist.filter(item => item !== id) : [...prevWishlist, id]
        );
    };

    return (
        <View style={styles.container}>
            {dummyProducts.map((item) => (
                <TouchableOpacity key={item.id}
                 onPress={() => navigation.navigate('Details', { productId: item.id })}
                  style={styles.mainContainer}>
                    <View style={[styles.subContainer, { backgroundColor: theme.backColor }]}>                        
                        <View style={styles.imgContainer}>
                            <Image source={{ uri: item.image }} style={styles.image} />
                        </View>
                        <View style={styles.detailsContainer}>
                            <Text style={[styles.text, { color: theme.textColor }]}>
                                {item.title.length > 25 ? `${item.title.slice(0, 25)}...` : item.title}
                            </Text>
                            <View style={styles.priceContainer}>
                                <Text style={[styles.text, { fontWeight: 'bold', color: theme.textColor }]}>RS. {item.price}</Text>
                                <TouchableOpacity onPress={() => toggleWishlist(item.id)}>
                                    <Ionicons name={wishlist.includes(item.id) ? 'heart' : 'heart-outline'} size={24} color={theme.themeColor} />
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </TouchableOpacity>
            ))}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingHorizontal: 5,
        flexDirection: 'row',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
    },
    mainContainer: {
        height: 250,
        width: '50%',
        paddingVertical: 5,
        paddingHorizontal: 5,
    },
    subContainer: {
        borderRadius: 10,
        elevation: 5,
    },
    imgContainer: {
        height: '65%',
        width: '100%',
    },
    image: {
        height: '100%',
        width: '100%',
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        resizeMode: 'contain',
        backgroundColor:"#fff"
    },
    detailsContainer: {
        height: '35%',
        width: '100%',
        padding: 10,
    },
    text: {
        fontSize: 16,
        textTransform: 'capitalize',
    },
    priceContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
});

export default ProductComponent;