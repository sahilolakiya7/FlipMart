import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import React from 'react';
import { useTheme } from '../../context/ThemeProvide';

const UserComponent = (props) => {
    const { dummyProducts } = props;
    const { theme } = useTheme();
    return (
        <View style={styles.container}>
            {dummyProducts.map((item) => (
                <TouchableOpacity key={item.id}  style={styles.mainContainer}>
                    <View style={[styles.subContainer, { backgroundColor: theme.backColor }]}>                        
                                <Text style={[styles.text, { fontWeight: 'bold', color: theme.textColor }]}>Username : {item.username}</Text>
                                <Text style={[styles.text, { fontWeight: 'bold', color: theme.textColor }]}>Email : {item.email}</Text>
                                <Text style={[styles.text, { fontWeight: 'bold', color: theme.textColor }]}>Password : {item.password}</Text>
                                <Text style={[styles.text, { fontWeight: 'bold', color: theme.textColor }]}>Name : {item.name.firstname} {item.name.lastname}</Text>
                    </View>
                </TouchableOpacity>
            ))}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingHorizontal: 5,
        // flexDirection: 'row',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        marginBottom:80
    },
    mainContainer: {
        // height: 110,
        width: '100%',
        paddingVertical: 5,
        paddingHorizontal: 5,
    },
    subContainer: {
        borderRadius: 10,
        elevation: 5,
        padding:10
    },
    imgContainer: {
        height: '65%',
        width: '100%',
    },
    image: {
        height: '100%',
        width: '100%',
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        resizeMode: 'contain',
        backgroundColor:"#fff"
    },
    detailsContainer: {
        height: '35%',
        width: '100%',
        padding: 10,
    },
    text: {
        fontSize: 16,
        textTransform: 'capitalize',
    },
    priceContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
});

export default UserComponent;