import {Text, StyleSheet, TouchableOpacity } from 'react-native';
import React, { useState } from 'react';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import { useTheme } from '../../context/ThemeProvide';
import { showMessage } from "react-native-flash-message";

const AddToCartButton = (props) => {
    const { theme } = useTheme();
    const [cartItems, setCartItems] = useState([]);

    const handleAddToCart = (item) => {
        const findElem = cartItems.find(x => x.productId === item.id);
        
        const formData = {
            product: item,
            qty: findElem ? findElem.qty + (props.qty || 1) : (props.qty || 1),
        };

        setCartItems([...cartItems.filter(x => x.productId !== item.id), formData]);

        showMessage({
            message: "Item added to cart successfully!",
            type: "success",
            color: "#FFF",
            style: { backgroundColor: theme.themeColor }
        });

        props?.setQty(1);
    };

    return (
        <TouchableOpacity 
            style={[styles.addToCartButtonContainer, { backgroundColor: theme.themeColor }]}
            onPress={() => handleAddToCart(props.item)}
        >
            <FontAwesome5 name='shopping-cart' size={props?.iconSize || 14} color={theme.whiteColor} />
            <Text style={{
                ...styles.addBtnText,
                color: theme.whiteColor,
                fontSize: props?.fontSize || 12,
            }}>Add TO Cart</Text>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    addToCartButtonContainer: {
        paddingHorizontal: 15,
        paddingVertical: 10,
        flexDirection: 'row',
        alignItems: 'center',
        borderRadius: 10,
    },
    addBtnText: {
        fontWeight: 'bold',
        marginLeft: 10,
        letterSpacing: 1,
    },
});

export default AddToCartButton;
