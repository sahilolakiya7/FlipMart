import { View,  StyleSheet } from 'react-native'
import React from 'react'
import { Button } from 'react-native-paper'
import { useTheme } from '../../context/ThemeProvide';

const ButtonComponent = (props) => {
     const { theme } = useTheme();
  return (
    <View style={{
        marginVertical:5,
    }}>
        <Button 
            labelStyle={{...styles.button}}
            icon={props?.icon}
            mode={props?.mode || "contained"}  // Default mode
        onPress={props?.onPress || (() => {})}  // Default function
        buttonColor={props?.buttonColor || theme.themeColor}
        textColor={props?.textColor || theme.whiteColor}
            style={[styles.noShadow,{borderColor:props?.borderColor ||theme.themeColor}]} 
        >
          {props?.title || "Click Me"} 
        </Button>
    </View>
  )
}

const styles = StyleSheet.create({
    button:{
        paddingVertical:5,
        fontSize:20
    }
    ,
        noShadow: {
            elevation: 0, // Android
            shadowColor: 'transparent', // iOS
            shadowOpacity: 0,
            shadowRadius: 0,
            shadowOffset: { width: 0, height: 0 },
            // borderColor:"#1111",
            borderWidth:0.5,
        }
});

export default ButtonComponent