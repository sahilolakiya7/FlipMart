import { View, StyleSheet } from 'react-native';
import React from 'react';
import TItleComponent from '../Title/TItleComponent';
import ProductComponent from '../Product/ProductComponent';
import { useNavigation } from '@react-navigation/native';

const PopularComponent = (props) => {
    const { dummyProducts } = props;
    const navigation = useNavigation();
    let renderProduct;
    if (props.title === "popular") {
        renderProduct = dummyProducts.filter((item) => item.popular_product === 1);
    } else {
        renderProduct = dummyProducts.filter((item) => item.new_arrivals_product === 1);
    }
    
    return (
        <View style={styles.container}>
            <TItleComponent title={props.title} onPress={() => navigation.navigate('Product')} />
                <ProductComponent dummyProducts={dummyProducts} renderSuccess={true} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        width: '100%',
    },
    emptyContainer: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    emptyBox: {
        height: 40,
        width: '50%',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 10,
        elevation: 4,
    },
    emptyText: {
        fontSize: 14,
        fontWeight: 'bold',
    }
});

export default PopularComponent;
