import { View, StyleSheet } from 'react-native'
import React from 'react'
import { TextInput  } from 'react-native-paper';
import { useTheme } from '../../context/ThemeProvide';

const InputComponent = (props) => {
    const {theme} = useTheme();
  return (
    <View style={{
        width:'100%',
    }}>
    <TextInput
        mode="outlined"
        label={props?.label}
        placeholder={props?.placeholder}
        activeOutlineColor={theme.themeColor}
        outlineStyle={{borderColor:theme.borderColor,borderRadius:10}}
        placeholderTextColor={theme.textColor}
        right={<TextInput.Icon icon={props?.icon} size={20} onPress={props?.onPressIcon}/>}
        value={props?.value}
        onChangeText={props?.onChangeText}
        {...props}
        style={{ 
          ...styles.text, 
          color:theme.textColor,
          backgroundColor: theme.backgroundColor 
      }}
    />
    </View>
  )
}

const styles = StyleSheet.create({
    text: {
        fontSize: 16,        
      },
});

export default InputComponent