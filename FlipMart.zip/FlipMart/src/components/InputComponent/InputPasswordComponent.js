import { View, StyleSheet } from 'react-native'
import React from 'react'
import { TextInput  } from 'react-native-paper';
import { useTheme } from '../../context/ThemeProvide';

const InputComponent = (props) => {
    const {theme} = useTheme();
  return (
    <View style={{
        marginVertical:5,
    }}>
    <TextInput
        mode="outlined"
        label={props?.label}
        placeholder={props?.placeholder}
        activeOutlineColor={theme.themeColor}
        outlineStyle={{borderColor:theme.themeColor}}
        style={{...styles.text}}
        right={<TextInput.Icon icon={props?.icon} />}
        {...props}
        
    />
    </View>
  )
}

const styles = StyleSheet.create({
    text: {
        fontSize: 18,
        height:50
      },
});

export default InputComponent