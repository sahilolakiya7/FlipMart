import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeProvide';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';

const IncrementDecrement = (props) => {
    const { qty, setQty } = props;
    const [stock, setStock] = useState(100);
    const { theme } = useTheme();

    const handleDecrement = () => {
        qty > 1 ? setQty(qty - 1) : setQty(1);
        console.log('Updated Qty:', qty - 1);
    };

    const handleIncrement = () => {
        qty < stock ? setQty(qty + 1) : setQty(stock);
        console.log('Updated Qty:', qty + 1);
    };

    return (
        <View>
            <View style={[styles.qtySubContainer, { borderColor: theme.borderColor }]}>
                <TouchableOpacity onPress={handleDecrement}>
                    <FontAwesome5 name='minus' size={14} color={theme.themeColor} />
                </TouchableOpacity>
                <Text style={[styles.qtyText, { color: theme.textColor }]}>{qty}</Text>
                <TouchableOpacity onPress={handleIncrement}>
                    <FontAwesome5 name='plus' size={14} color={theme.themeColor} />
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    qtySubContainer: {
        height: 30,
        width: 80,
        borderWidth: 1,
        borderRadius: 5,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
    },
    qtyText: {
        fontSize: 14,
        fontWeight: 'bold',
    },
});

export default IncrementDecrement;
