import { View, Text, StyleSheet, TouchableOpacity } from 'react-native'
import React from 'react'
import { useTheme } from '../../context/ThemeProvide'

const TItleComponent = (props) => {
    const {theme} = useTheme();
  return (
    <View style={styles.container}>
      <Text style={[styles.title,{
        fontSize:18,
        color:theme.textColor,
      }]}>{props.title}</Text>
      <TouchableOpacity onPress={props.onPress}>
        <Text style={[styles.title,{
            fontSize:14,
            color:theme.themeColor,
        }]}>view all</Text>
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        height:60,
        width:'100%',
        flexDirection:'row',
        justifyContent:'space-between',
        alignItems:'center',
        paddingHorizontal:10,
    },
    title:{
        fontWeight:'bold',
        textTransform:'capitalize',
    },
});

export default TItleComponent