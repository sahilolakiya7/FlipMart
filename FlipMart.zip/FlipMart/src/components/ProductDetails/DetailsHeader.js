import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import React, { useState } from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useTheme } from '../../context/ThemeProvide';
import { showMessage } from 'react-native-flash-message';

const DetailsHeader = (props) => {
    const { theme } = useTheme();
    const [wishItems, setWishItems] = useState([]);

    const handleWish = (id) => {
        if (wishItems.includes(id)) {
            setWishItems(wishItems.filter(item => item !== id));
            showMessage({
                message: 'Removed from Wishlist',
                type: 'danger',
                color: '#FFF',
                style: { backgroundColor: theme.themeColor },
            });
        } else {
            setWishItems([...wishItems, id]);
            showMessage({
                message: 'Added to Wishlist',
                type: 'success',
                color: '#FFF',
                style: { backgroundColor: theme.themeColor },
            });
        }
    };

    return (
        <View style={[styles.headerContainer,{ backgroundColor: theme.backgroundColor }]}>
            <View>
                <View style={[styles.offer, { backgroundColor: theme.COLORS.success }]}>  
                    <Text style={{ fontWeight: 'bold', color: theme.COLORS.white }}>40% off</Text>
                </View>
            </View>
            <View style={[styles.header, { backgroundColor: theme.backgroundColor }]}>  
                <TouchableOpacity onPress={() => handleWish(props?.item.id)}>
                    <Ionicons 
                        name={wishItems.includes(props?.item.id) ? 'heart' : 'heart-outline'} 
                        size={24} 
                        color={theme.themeColor} 
                    />
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    headerContainer: {
        height: 50,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 10,
    },
    offer: {
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 5,
    },
    header: {
        padding: 10,
        borderRadius: 25,
    },
});

export default DetailsHeader;
