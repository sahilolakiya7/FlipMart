import { View, Text, StyleSheet } from 'react-native';
import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeProvide';
import IncrementDecrement from '../IncrementDecrement/IncrementDecrement';
import AddToCartButton from '../Buttons/AddToCartButton';

const DetailsComponent = ({ item = dummyItem }) => {
  const [qty, setQty] = useState(1);
  const { theme } = useTheme();
  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundColor }]}>
      <View style={styles.mainContainer}>
        <View style={styles.titleContainer}>
          <Text style={[styles.titleText, { color: theme.themeColor }]}>
            {item?.title}
          </Text>
        </View>

        <View style={styles.detailsContainer}>
        <Text style={{ ...styles.tagsStyles,  }}>
            {item?.description}
          </Text>
        </View>

        <View style={styles.qtyContainer}>
          <Text style={{ ...styles.qtyText, color: theme.textColor, marginRight: 10 }}>
            QTY
          </Text>
          <IncrementDecrement qty={qty} setQty={setQty} />
          <Text style={{ ...styles.qtyText, color: theme.textColor, marginLeft: 10 }}>
            {`( MOQ ${item?.no_of_pc} )`}
          </Text>
        </View>
        <View style={styles.addToCartContainer}>
          <View style={styles.priceContainer}>
            <Text style={[styles.priceText, { color: theme.themeColor }]}>
              {`Rs. ${item?.price}`}
            </Text>
          </View>
          <AddToCartButton fontSize={16} iconSize={18} item={item} qty={qty} setQty={setQty} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 20,
    paddingVertical: 30,
    borderTopLeftRadius: 40,
    borderTopRightRadius: 40,
    elevation: 5,
  },
  mainContainer: {},
  titleContainer: {
    paddingHorizontal: 10,
  },
  titleText: {
    fontSize: 22,
    fontWeight: 'bold',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  detailsContainer: {
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  qtyContainer: {
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  qtyText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  addToCartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
  },
  priceContainer: {
    justifyContent: 'center',
  },
  priceText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
});

export default DetailsComponent;
