const colors = {
    primary:'#2089DC',
    secondary:'#CA71EB',
    white:'#FFFFFF',
    black:'#111111',
    blacka:'#242424',

    grey0:'#393E42',
    grey1:'#43484D',
    grey2:'#50484D',
    grey3:'#86939E',
    grey4:'#BDC6CF',
    grey5:'#E1E8EE',
    grey7:'#e5e5e5',
    grey8:'#F7F7F7',
    grey9:'#f5f5f5',
    greyOutline:'#BBBBBB',
    searchBg:'#303337',
    success:'#6DE17F',
    error:'#FF190C',
    warning:'#F07C00',
    disabled:'#E3E6E8',
}
export const lightTheme = {
    COLORS:{
        primary:colors.primary,
        secondary:colors.secondary,
        white:colors.white,
        black:colors.black,
        grey0:colors.grey0,
        grey1:colors.grey1,
        grey2:colors.grey2,
        grey3:colors.grey3,
        grey4:colors.grey4,
        grey5:colors.grey5,
        grey7:colors.grey7,
        grey8:colors.grey8,
        grey9:colors.grey9,
        greyOutline:colors.greyOutline,
        searchBg:colors.searchBg,
        success:colors.success,
        error:colors.error,
        warning:colors.warning,
        disabled:colors.disabled,
    },
    appColor:colors.grey8,
    backgroundColor: colors.white,  // ✅ Corrected this
    themeColor:colors.warning,
    textColor:colors.grey1,
    borderColor:colors.grey4,
    backColor:colors.grey9,
    whiteColor: colors.white,
    tabColor:colors.grey8
}

export const darkTheme = {
    COLORS:{
        primary: colors.primary,
        secondary: colors.secondary,
        white: colors.white,
        black: colors.black,
        grey0: colors.grey0,
        grey1: colors.grey1,
        grey2: colors.grey2,
        grey3: colors.grey3,
        grey4: colors.grey4,
        grey5: colors.grey5,
        grey7: colors.grey7,
        grey8: colors.grey8,
        grey9: colors.grey9,
        greyOutline: colors.greyOutline,
        searchBg: colors.searchBg,
        success: colors.success,
        error: colors.error,
        warning: colors.warning,
        disabled: colors.disabled,
    },
    appColor: colors.black, // Dark mode background
    backgroundColor: colors.grey0, // ✅ Corrected this
    themeColor: colors.warning, // Keep a visible theme color
    textColor: colors.white, // White text for readability
    borderColor: colors.grey4, // Use a slightly lighter border
    backColor:colors.grey1,
    whiteColor: colors.white,
    tabColor:colors.grey3
};
