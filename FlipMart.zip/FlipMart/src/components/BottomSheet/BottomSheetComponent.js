import React,{useCallback, useMemo, useRef } from 'react'
import BottomSheet, { BottomSheetScrollView } from '@gorhom/bottom-sheet';
import { useTheme } from '../../context/ThemeProvide';

const BottomSheetComponent = (props) => {
  const {theme} = useTheme();
  const bottomSheetRef = useRef(null);
  
  const snapPoints = useMemo(() => ['25%', '50%','90%'], []);

  const handleSheetChanges = useCallback((index) => {
    if(index === -1){
      props?.setSheetIndex(-1);
    }
  }, []);
  return (
    <BottomSheet
        ref={bottomSheetRef}
        index={props?.index}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}
        enablePanDownToClose={true}
        handleIndicatorStyle={{backgroundColor:theme.themeColor}}
        backgroundStyle={{ backgroundColor: theme.backgroundColor }}
      >
        <BottomSheetScrollView>
        {props.children}
        </BottomSheetScrollView>
      </BottomSheet>

  )
}

export default BottomSheetComponent