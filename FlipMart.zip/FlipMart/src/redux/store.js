import {createStore,applyMiddleware} from 'redux';
const middleware = [];
const store = createStore(
    applyMiddleware(...middleware),
);

export default store;