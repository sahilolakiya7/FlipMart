/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';
import ThemeProvide from './src/context/ThemeProvide';
import MainScreen from './src/screens/MainScreen';
import 'react-native-gesture-handler';
import { Provider as PaperProvider } from 'react-native-paper';

const App = () => {
 return (
    <ThemeProvide>
      <PaperProvider>
        <MainScreen />
      </PaperProvider>
    </ThemeProvide>
  );
}


export default App;
