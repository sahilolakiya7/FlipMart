const images = {
   App_logo: require('./logo_.png'),
   banner_2: require('./banner_2.png'),
   banner_3: require('./banner_3.png'),
   banner_4: require('./banner_4.png'),
}
export default images;