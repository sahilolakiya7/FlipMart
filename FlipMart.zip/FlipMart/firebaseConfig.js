// src/config/firebaseConfig.js

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

// ✅ Use your own Firebase values
const firebaseConfig = {
  apiKey: "AIzaSyCIOFFS-UP7jO59YMTob7J2YbOVkBvMDTA",
  authDomain: "flipmart-f767b.firebaseapp.com",
  projectId: "flipmart-f767b",
  storageBucket: "flipmart-f767b.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456"
};

// ✅ Initialize only once
const app = initializeApp(firebaseConfig);

// ✅ Export initialized auth
const auth = getAuth(app);

export { auth };
